document.addEventListener('DOMContentLoaded', function() {
  const searchInput = document.getElementById('searchInput');
  const searchBtn = document.getElementById('searchBtn');
  const resultsDiv = document.getElementById('results');
  const refreshBtn = document.getElementById('refreshBtn');
  const settingsBtn = document.getElementById('settingsBtn');
  const settingsPanel = document.getElementById('settingsPanel');
  const changeSheetBtn = document.getElementById('changeSheetBtn');
  const toggleRecentEl = document.getElementById('toggleRecent');
  const toggleMemoEl = document.getElementById('toggleMemo');
  const favoritesResetBtn = document.getElementById('favoritesResetBtn');

  let SHEET_ID = '';
  let SHEET_URL = '';
  
  const GFA_BASE = 'https://ads.naver.com/manage/ad-accounts/';

  let advertisers = [];
  let favorites = [];
  let accessCount = {};
  let defaultManagerAccountNo = '';

  // ── 설정값 ──
  let showRecent = true;
  let showMemo = true;
  let memoText = '';
  let memoSaveTimer = null;
  
  const FAVORITES_PAGE_SIZE = 6;
  let favoritesPage = 0;

  const storage = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync)
    ? chrome.storage.sync
    : null;

  // ====================================================================
  // 1. 공통 헬퍼 함수
  // ====================================================================

  function saveConfig() {
    if (storage) {
      try {
        storage.set({ 'sheetId': SHEET_ID });
      } catch (e) {
        console.warn('설정 저장 실패:', e);
      }
    }
  }

  function updateSheetUrl() {
    if (SHEET_ID) {
      SHEET_URL = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv`;
    }
  }

  function saveFavorites() {
    if (!storage) return;
    try { 
      storage.set({ favorites }); 
    } catch (e) { 
      console.warn('favorites 저장 실패:', e); 
    }
  }

  function saveAccessCount() {
    if (!storage) return;
    try { storage.set({ accessCount }); } catch (e) { console.warn('accessCount 저장 실패:', e); }
  }

  function saveDisplaySettings() {
    if (!storage) return;
    try { storage.set({ showRecent, showMemo }); } catch (e) { console.warn('displaySettings 저장 실패:', e); }
  }

  function saveMemo() {
    if (!storage) return;
    try { storage.set({ memoText }); } catch (e) { console.warn('memo 저장 실패:', e); }
  }

  function recordAccess(name) {
    if (!name) return;
    accessCount[name] = (accessCount[name] || 0) + 1;
    saveAccessCount();
  }

  function getTopAccessed(n = 5) {
    return Object.entries(accessCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, n)
      .map(([name, count]) => ({ name, count }));
  }

  function parseCSVLine(line) {
    const result = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        if (inQuotes && line[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    return result;
  }

  function showStatus(message, type) {
    const statusDiv = document.getElementById('status');
    if (statusDiv) {
      statusDiv.textContent = message;
      statusDiv.className = `status ${type}`;
      setTimeout(() => {
        statusDiv.textContent = '';
        statusDiv.className = 'status';
      }, 3000);
    }
  }

  // ====================================================================
  // 2. 설정 패널 관련
  // ====================================================================

  function openSettingsPanel() {
    settingsPanel.style.display = 'block';
    settingsBtn.classList.add('active');
  }

  function closeSettingsPanel() {
    settingsPanel.style.display = 'none';
    settingsBtn.classList.remove('active');
  }

  function toggleSettingsPanel() {
    if (settingsPanel.style.display === 'none' || settingsPanel.style.display === '') {
      openSettingsPanel();
    } else {
      closeSettingsPanel();
    }
  }

  // 설정 패널 외부 클릭 시 닫기
  document.addEventListener('click', function(e) {
    if (
      settingsPanel.style.display !== 'none' &&
      !settingsPanel.contains(e.target) &&
      e.target !== settingsBtn
    ) {
      closeSettingsPanel();
    }
  });

  // ====================================================================
  // 3. 즐겨찾기 관련 함수
  // ====================================================================
  
  function updateStarIcons() {
    const stars = document.querySelectorAll('.favorite-star');
    stars.forEach(star => {
      const companyName = star.getAttribute('data-company');
      const isFavorite = favorites.some(fav => fav.name === companyName);
      star.textContent = isFavorite ? '★' : '☆';
      star.title = isFavorite ? '즐겨찾기 해제' : '즐겨찾기 추가';
      star.classList.toggle('active', isFavorite);
    });
  }

  function renderFavorites() {
    const favoritesList = document.getElementById('favoritesList');
    if (!favoritesList) return;

    const totalPages = Math.ceil(favorites.length / FAVORITES_PAGE_SIZE);
    if (favoritesPage < 0) favoritesPage = 0;
    if (favoritesPage > totalPages - 1) favoritesPage = Math.max(0, totalPages - 1);

    const start = favoritesPage * FAVORITES_PAGE_SIZE;
    const end = start + FAVORITES_PAGE_SIZE;
    const pageItems = favorites.slice(start, end);

    favoritesList.innerHTML = ''; 

    pageItems.forEach(fav => {
      const item = document.createElement('div');
      item.className = 'favorite-item';
      item.innerHTML = `
        <button class="fav-remove" title="즐겨찾기 해제" data-remove="${fav.name}">✕</button>
        <div class="favorite-name" title="${fav.name}">${fav.name}</div>
        <div class="favorite-buttons">
          ${fav.accountId ? `<button class="goto-btn gfa" data-account="${fav.accountId}" data-accessno="${fav.accessNo}">광고주센터</button>` : ''}
          ${fav.accountId ? `<button class="goto-btn adcenter" data-account="${fav.accountId}" data-accessno="${fav.accessNo}">통합</button>` : ''}
        </div>
      `;
      favoritesList.appendChild(item);
    });

    if (totalPages > 1) {
      const pag = document.createElement('div');
      pag.className = 'favorites-pagination';
      pag.innerHTML = `
        <button class="fav-page-btn" data-action="prev">이전</button>
        <span class="favorites-page-indicator">${favoritesPage + 1} / ${totalPages}</span>
        <button class="fav-page-btn" data-action="next">다음</button>
      `;
      favoritesList.appendChild(pag);
    }
  }

  function updateFavoritesVisibility() {
    const favoritesSection = document.getElementById('favoritesSection');
    const searchValue = searchInput.value.trim();
    if (searchValue === '') {
      if (favorites.length > 0) {
        favoritesSection.style.display = 'block';
        renderFavorites();
      } else {
        favoritesSection.style.display = 'none';
      }
      if (advertisers.length > 0) {
        displayInitialStats();
      } else {
        resultsDiv.innerHTML = '<div class="no-results">데이터 로드 후 검색 또는 새로고침을 해주세요.</div>';
      }
    } else {
      favoritesSection.style.display = 'none';
      if (resultsDiv.innerHTML.trim() === '') {
        resultsDiv.innerHTML = '<div class="no-results">검색 결과가 없습니다.</div>';
      }
    }
  }
  
  function resetFavorites() {
    if (confirm('⚠️ 모든 즐겨찾기 목록을 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.')) {
        favorites = [];
        saveFavorites();
        favoritesPage = 0;
        updateFavoritesVisibility();
        updateStarIcons();
        showStatus('즐겨찾기 목록이 초기화되었습니다.', 'info');
    }
  }


  // ====================================================================
  // 4. 메인 로직 함수
  // ====================================================================

  async function loadFavorites() {
    return new Promise((resolve) => {
      if (!storage) { resolve([]); return; }
      try {
        storage.get(['favorites', 'accessCount', 'showRecent', 'showMemo', 'memoText'], function(result) {
          if (Array.isArray(result.favorites)) favorites = result.favorites;
          if (result.accessCount && typeof result.accessCount === 'object') accessCount = result.accessCount;
          if (typeof result.showRecent === 'boolean') showRecent = result.showRecent;
          if (typeof result.showMemo === 'boolean') showMemo = result.showMemo;
          if (typeof result.memoText === 'string') memoText = result.memoText;

          // 토글 UI 동기화
          if (toggleRecentEl) toggleRecentEl.checked = showRecent;
          if (toggleMemoEl) toggleMemoEl.checked = showMemo;

          resolve(favorites);
        });
      } catch (e) { 
        console.warn('favorites 불러오기 실패:', e); 
        resolve([]); 
      }
    });
  }


  async function checkAndSetupConfig() {
    if (storage) {
      return new Promise((resolve) => {
        storage.get(['sheetId'], function(result) {
          if (result.sheetId) {
            SHEET_ID = result.sheetId;
            updateSheetUrl();
            resolve(true);
          } else {
            promptForConfig().then((success) => {
              resolve(success);
            });
          }
        });
      });
    } else {
      return promptForConfig();
    }
  }

  function promptForConfig() {
    return new Promise((resolve) => {
      const sheetUrl = prompt(
        '🔧 초기 설정\n\n구글 스프레드시트의 전체 URL을 입력하세요:'
      );

      if (sheetUrl && sheetUrl.trim()) {
        const urlMatch = sheetUrl.match(/\/d\/(.*?)(?:\/edit|\/view|\/pub|\/export|\/gviz|\/copy|$)/);
        if (urlMatch && urlMatch[1]) {
          SHEET_ID = urlMatch[1];
          updateSheetUrl();
          saveConfig();
          showStatus('✅ 설정이 완료되었습니다!', 'success');
          resolve(true);
        } else {
          showStatus('❌ 유효하지 않은 스프레드시트 URL입니다.', 'error');
          resolve(false);
        }
      } else {
        showStatus('❌ 설정이 취소되었습니다.', 'error');
        resolve(false);
      }
    });
  }
  

  async function loadAdvertisersFromSheet() {
    if (!SHEET_URL) {
      showStatus('❌ 스프레드시트가 설정되지 않았습니다.', 'error');
      return;
    }

    showStatus('📊 데이터를 로드하는 중...', 'info');
    
    try {
      const response = await fetch(SHEET_URL, { method: 'GET', mode: 'cors' });
      if (!response.ok) throw new Error(`시트 로드 실패: HTTP ${response.status}`);
      
      const csvText = await response.text();
      const lines = csvText.split(/\r?\n/).filter(line => line.trim());
      
      if (lines.length < 2) throw new Error('데이터가 충분하지 않습니다. (헤더 포함 2행 이상 필요)');

      advertisers = [];

      for (let i = 1; i < lines.length; i++) {
        const values = parseCSVLine(lines[i]);

        const accessNo       = (values[0] || '').trim();
        const accountId      = (values[1] || '').trim();
        const name           = (values[2] || '').trim();
        const type           = (values[3] || '').trim();
        const contact        = (values[4] || '').trim();
        const emailAddress   = (values[5] || '').trim();
        const homepage       = (values[6] || '').trim();
        const businessRegNo  = (values[7] || '').trim();
        const note           = (values[8] || '').trim();

        if (!accessNo && !accountId && !name) continue;

        advertisers.push({
          accessNo, accountId, name, type, contact,
          emailAddress, homepage, businessRegNo, note,
        });

        if (!defaultManagerAccountNo && accessNo) {
          defaultManagerAccountNo = accessNo;
        }
      }
      
      showStatus(`✅ 광고주 ${advertisers.length}개 로드 완료`, 'success');
      
    } catch (error) {
      console.error('스프레드시트 로드 실패:', error);
      showStatus(`❌ 로드 실패: ${error.message}`, 'error');
    }
  }

  
  function searchAdvertisers(query) {
    if (!query || !query.trim()) return [];
    const searchTerm = query.toLowerCase().trim();
    
    return advertisers.filter(ad => {
      return (
        (ad.name          && ad.name.toLowerCase().includes(searchTerm))      ||
        (ad.accountId     && ad.accountId.toString().includes(searchTerm))    ||
        (ad.accessNo      && ad.accessNo.toString().includes(searchTerm))     ||
        (ad.type          && ad.type.toLowerCase().includes(searchTerm))      ||
        (ad.contact       && ad.contact.includes(searchTerm))                 ||
        (ad.emailAddress  && ad.emailAddress.toLowerCase().includes(searchTerm)) ||
        (ad.homepage      && ad.homepage.toLowerCase().includes(searchTerm))  ||
        (ad.businessRegNo && ad.businessRegNo.includes(searchTerm))           ||
        (ad.note          && ad.note.toLowerCase().includes(searchTerm))
      );
    });
  }

  function displayResults(results) {
    resultsDiv.innerHTML = '';
    
    if (results.length === 0) {
      resultsDiv.innerHTML = '<div class="no-results">검색 결과가 없습니다.</div>';
      return;
    }

    results.forEach(ad => {
      const item = document.createElement('div');
      item.className = 'result-item';

      const isFavorite = favorites.some(f => f.name === ad.name);
      const starIcon = isFavorite ? '★' : '☆';
      const starClass = isFavorite ? 'active' : '';

      const typeHtml = ad.type ? `
        <div class="detail-row">
          <div class="detail-left">
            <span class="label">담당자</span>
            <span class="detail-value">${ad.type}</span>
          </div>
        </div>` : '';

      const contactHtml = ad.contact ? `
        <div class="detail-row">
          <div class="detail-left">
            <span class="label">연락처</span>
            <span class="detail-value">${ad.contact}</span>
          </div>
        </div>` : '';

      const emailHtml = ad.emailAddress ? `
        <div class="detail-row">
          <div class="detail-left">
            <span class="label">이메일</span>
            <span class="detail-value" style="word-break:break-all;">${ad.emailAddress}</span>
          </div>
        </div>` : '';

      let homepageHtml = '';
      if (ad.homepage) {
        let url = ad.homepage.trim();
        if (!url.startsWith('http://') && !url.startsWith('https://')) url = 'https://' + url;
        homepageHtml = `
          <div class="detail-row">
            <div class="detail-left">
              <span class="label">URL</span>
              <span class="detail-value">
                <a href="${url}" target="_blank" class="homepage-link" title="${ad.homepage}">${ad.homepage}</a>
              </span>
            </div>
          </div>`;
      }

      const bizRegHtml = ad.businessRegNo ? `
        <div class="detail-row">
          <div class="detail-left">
            <span class="label">사업자번호</span>
            <span class="detail-value">${ad.businessRegNo}</span>
          </div>
        </div>` : '';

      const noteHtml = ad.note ? `
        <div class="detail-row" style="border-bottom:none;">
          <div class="detail-left">
            <span class="label">메모</span>
            <span class="detail-value" style="word-break:break-all; white-space:normal;">${ad.note}</span>
          </div>
        </div>` : '';

      const detailsBody = typeHtml + contactHtml + emailHtml + homepageHtml + bizRegHtml + noteHtml;
      const detailsHtml = detailsBody.trim() ? `<div class="advertiser-details">${detailsBody}</div>` : '';

      const mainButtonsHtml = ad.accountId ? `
        <div class="main-ad-buttons">
          <button class="goto-btn gfa" data-account="${ad.accountId}" data-accessno="${ad.accessNo}">광고주센터</button>
          <button class="goto-btn adcenter" data-account="${ad.accountId}" data-accessno="${ad.accessNo}">통합 대시보드</button>
        </div>` : '';

      const displayName = ad.name || '(미등록)';
      const displayAccountId = ad.accountId ? `<span class="name-account-id">(${ad.accountId})</span>` : '';

      item.innerHTML = `
        <div class="advertiser-name">
          <div class="name-row">
            <span class="name-text">${displayName}</span>
            ${displayAccountId}
          </div>
          <span class="favorite-star ${starClass}"
                data-company="${ad.name || ad.accountId}"
                data-account="${ad.accountId}"
                data-accessno="${ad.accessNo}"
                title="${isFavorite ? '즐겨찾기 해제' : '즐겨찾기 추가'}">${starIcon}</span>
        </div>
        ${mainButtonsHtml}
        ${detailsHtml}
      `;
      resultsDiv.appendChild(item);
    });
  }


  // ====================================================================
  // 5. 초기 화면 (자주 접속한 업체 + 메모)
  // ====================================================================

  function renderMemoSection() {
    const wrap = document.createElement('div');
    wrap.className = 'memo-wrap';
    wrap.id = 'memoWrap';

    wrap.innerHTML = `
      <div class="memo-header">
        <span class="memo-header-title">메모</span>
        <span class="memo-save-indicator" id="memoSaveIndicator">자동저장</span>
      </div>
      <div class="memo-body">
        <textarea
          class="memo-textarea"
          id="memoTextarea"
          placeholder="잊지 말아야 할 중요 사항을 메모해두세요…&#10;(작성 즉시 자동으로 저장됩니다)"
        >${memoText}</textarea>
      </div>
    `;

    // 이벤트 연결 (렌더 후 즉시)
    setTimeout(() => {
      const ta = document.getElementById('memoTextarea');
      const indicator = document.getElementById('memoSaveIndicator');
      if (!ta) return;

      ta.addEventListener('input', function() {
        memoText = this.value;
        if (indicator) { indicator.textContent = '저장 중…'; indicator.classList.remove('saved'); }
        clearTimeout(memoSaveTimer);
        memoSaveTimer = setTimeout(() => {
          saveMemo();
          if (indicator) { indicator.textContent = '저장됨 ✓'; indicator.classList.add('saved'); }
          setTimeout(() => {
            if (indicator) { indicator.textContent = '자동저장'; indicator.classList.remove('saved'); }
          }, 2000);
        }, 600);
      });
    }, 0);

    return wrap;
  }

  function displayInitialStats() {
    resultsDiv.innerHTML = '';

    const top = getTopAccessed(5);
    const hasRecent = showRecent;
    const hasMemo = showMemo;

    // ── 자주 접속한 업체
    if (hasRecent) {
      const wrap = document.createElement('div');
      wrap.className = 'recent-wrap';

      const header = document.createElement('div');
      header.className = 'recent-header';
      header.textContent = '자주 접속한 업체';
      wrap.appendChild(header);

      if (top.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'recent-empty';
        empty.innerHTML = `
          <div class="recent-empty-icon">🔍</div>
          <div class="recent-empty-text">광고주를 검색하면<br>자주 접속한 업체가 여기에 표시됩니다.</div>
        `;
        wrap.appendChild(empty);
      } else {
        top.forEach((item, idx) => {
          const row = document.createElement('div');
          row.className = 'recent-item';
          row.setAttribute('data-name', item.name);
          row.innerHTML = `
            <span class="recent-rank">${idx + 1}</span>
            <span class="recent-name">${item.name}</span>
            <span class="recent-count">${item.count}회</span>
          `;
          row.addEventListener('click', function() {
            searchInput.value = item.name;
            performSearch();
          });
          wrap.appendChild(row);
        });
      }

      resultsDiv.appendChild(wrap);
    }

    // ── 메모
    if (hasMemo) {
      resultsDiv.appendChild(renderMemoSection());
    }

    // 둘 다 꺼져 있을 때
    if (!hasRecent && !hasMemo) {
      resultsDiv.innerHTML = '<div class="no-results" style="padding-top:40px;">설정에서 표시할 항목을 켜주세요.</div>';
    }
  }


  function performSearch() {
    const query = searchInput.value.trim();
    if (query) {
      if (!SHEET_ID) {
        showStatus('❌ 스프레드시트가 설정되지 않았습니다.', 'error');
        return;
      }
      if (advertisers.length === 0) {
        showStatus('❌ 데이터가 로드되지 않았습니다. 새로고침을 눌러주세요.', 'error');
        return;
      }
      const results = searchAdvertisers(query);
      displayResults(results);
    } else {
      displayInitialStats();
    }
    updateFavoritesVisibility();
  }


  // ====================================================================
  // 6. 외부 링크/이벤트 핸들러 함수
  // ====================================================================

  window.goToGFA = function(accountId, accessNo) {
    const url = `${GFA_BASE}${accountId}/dashboard?accessManagerAccountNo=${accessNo}`;
    if (typeof chrome !== 'undefined' && chrome.tabs) {
      chrome.tabs.create({ url });
    } else {
      window.open(url, '_blank');
    }
  };

  window.goToIntegratedCenter = function(accountId, accessNo) {
    const managerNo = accessNo || defaultManagerAccountNo;
    const url = `https://ads.naver.com/account/${managerNo}/dashboard?accessManagerAccountNo=${managerNo}`;
    if (typeof chrome !== 'undefined' && chrome.tabs) {
      chrome.tabs.create({ url });
    } else {
      window.open(url, '_blank');
    }
  };
  
  window.goToManagerDashboard = function() {
    const url = `https://ads.naver.com/account/${defaultManagerAccountNo}/dashboard?accessManagerAccountNo=${defaultManagerAccountNo}`;
    if (typeof chrome !== 'undefined' && chrome.tabs) {
      chrome.tabs.create({ url });
    } else {
      window.open(url, '_blank');
    }
  };
  
  window.toggleFavorite = function(companyName, accountId, accessNo) {
    const existingIndex = favorites.findIndex(fav => fav.name === companyName);
    if (existingIndex >= 0) {
      favorites.splice(existingIndex, 1);
    } else {
      favorites.unshift({
        id: 'fav_' + Date.now(),
        name: companyName,
        accountId: accountId || '',
        accessNo: accessNo || '',
      });
    }
    favoritesPage = 0;
    saveFavorites();
    updateFavoritesVisibility();
    updateStarIcons();
  };


  // ====================================================================
  // 7. 이벤트 리스너 등록
  // ====================================================================

  // ── 설정 버튼
  if (settingsBtn) {
    settingsBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      toggleSettingsPanel();
    });
  }

  // ── 광고주 리스트 변경
  if (changeSheetBtn) {
    changeSheetBtn.addEventListener('click', function() {
      closeSettingsPanel();
      if (confirm('⚙️ 스프레드시트 URL을 변경하시겠습니까?')) {
        promptForConfig().then((success) => {
          if (success) {
            loadAdvertisersFromSheet();
          }
        });
      }
    });
  }

  // ── 자주 접속한 업체 토글
  if (toggleRecentEl) {
    toggleRecentEl.addEventListener('change', function() {
      showRecent = this.checked;
      saveDisplaySettings();
      if (searchInput.value.trim() === '') {
        displayInitialStats();
      }
    });
  }

  // ── 메모 토글
  if (toggleMemoEl) {
    toggleMemoEl.addEventListener('change', function() {
      showMemo = this.checked;
      saveDisplaySettings();
      if (searchInput.value.trim() === '') {
        displayInitialStats();
      }
    });
  }

  // ── 새로고침 버튼
  if (refreshBtn) {
    refreshBtn.addEventListener('click', function() {
      if (!SHEET_ID) {
        showStatus('❌ 스프레드시트가 설정되지 않았습니다.', 'error');
        return;
      }
      showStatus('📊 데이터를 새로고침하는 중...', 'info');
      loadAdvertisersFromSheet().then(() => {
        if (searchInput.value.trim() === '') {
          displayInitialStats();
        } else {
          performSearch();
        }
      });
    });
  }

  searchBtn.addEventListener('click', performSearch);
  
  searchInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') performSearch();
  });
  
  searchInput.addEventListener('input', function() {
    if (this.value.trim() === '') {
      performSearch();
    }
  });

  if (favoritesResetBtn) {
    favoritesResetBtn.addEventListener('click', resetFavorites);
  }
  
  const goToIntegratedDashboardBtn = document.getElementById('goToIntegratedDashboardBtn');
  if (goToIntegratedDashboardBtn) {
    goToIntegratedDashboardBtn.addEventListener('click', window.goToManagerDashboard);
  }

  resultsDiv.addEventListener('click', function(e) {
    const star = e.target.closest('.favorite-star');
    if (star) {
      toggleFavorite(
        star.getAttribute('data-company') || '',
        star.getAttribute('data-account') || '',
        star.getAttribute('data-accessno') || ''
      );
      return;
    }
    
    const gfaBtn = e.target.closest('.goto-btn.gfa');
    if (gfaBtn) {
      const accountId = gfaBtn.getAttribute('data-account');
      const accessNo = gfaBtn.getAttribute('data-accessno');
      const cardName = gfaBtn.closest('.result-item')?.querySelector('.name-text')?.textContent?.trim();
      if (cardName) recordAccess(cardName);
      if (accountId) goToGFA(accountId, accessNo);
      return;
    }
    
    const adcenterBtn = e.target.closest('.goto-btn.adcenter');
    if (adcenterBtn) {
      const accountId = adcenterBtn.getAttribute('data-account');
      const accessNo = adcenterBtn.getAttribute('data-accessno');
      const cardName = adcenterBtn.closest('.result-item')?.querySelector('.name-text')?.textContent?.trim();
      if (cardName) recordAccess(cardName);
      if (accountId) goToIntegratedCenter(accountId, accessNo);
      return;
    }
  });

  const favoritesListEl = document.getElementById('favoritesList');
  favoritesListEl.addEventListener('click', function(e) {
    const pageBtn = e.target.closest('.fav-page-btn');
    if (pageBtn) {
      const action = pageBtn.getAttribute('data-action');
      if (action === 'prev') favoritesPage = Math.max(0, favoritesPage - 1);
      if (action === 'next') favoritesPage = Math.min(Math.ceil(favorites.length / FAVORITES_PAGE_SIZE) - 1, favoritesPage + 1);
      renderFavorites();
      return;
    }
    
    const removeBtn = e.target.closest('.fav-remove');
    if (removeBtn) {
      const name = removeBtn.getAttribute('data-remove');
      const idx = favorites.findIndex(f => f.name === name);
      if (idx >= 0) {
        favorites.splice(idx, 1);
        saveFavorites();
        const maxPage = Math.max(0, Math.ceil(favorites.length / FAVORITES_PAGE_SIZE) - 1);
        if (favoritesPage > maxPage) favoritesPage = maxPage;
        updateFavoritesVisibility();
        updateStarIcons();
      }
      return;
    }
    
    const gfaBtn = e.target.closest('.goto-btn.gfa');
    if (gfaBtn && gfaBtn.getAttribute('data-account')) {
      goToGFA(gfaBtn.getAttribute('data-account'), gfaBtn.getAttribute('data-accessno'));
      return;
    }
    
    const acBtn = e.target.closest('.goto-btn.adcenter');
    if (acBtn && acBtn.getAttribute('data-account')) {
      goToIntegratedCenter(acBtn.getAttribute('data-account'), acBtn.getAttribute('data-accessno'));
      return;
    }
  });


  (async function init() {
    await loadFavorites();
    
    const configSuccess = await checkAndSetupConfig();
    if (configSuccess) {
      await loadAdvertisersFromSheet();
      if (advertisers.length > 0 && searchInput.value.trim() === '') {
        updateFavoritesVisibility();
      }
    } else {
      showStatus('⚠️ 설정이 완료되지 않았습니다.', 'error');
    }
  })();
});
